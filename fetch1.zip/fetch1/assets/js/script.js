const menu = document.getElementById('menu')
const products= document.getElementById('products')
fetch('https://fakestoreapi.com/products/categories/')
.then(x=>x.json())
.then(y=>{
    y.map(category=>{
        console.log(category)
        menu.innerHTML += `
        <li onclick="getdata(this)">${category}</li>
        `

    })
})
let text =''
function getdata(e){
    products.innerHTML = ''
    text = e.innerText
    showdata(text)

}

function showdata(x){
    fetch(`https://fakestoreapi.com/products/category/${x}`)
    .then(x=>x.json())
    .then(y=>{
        y.map(productcard=>{
            console.log(productcard)
            let DIV =document.createElement('div')
            let title =document.createElement('h1')
            let photo= document.createElement('img')
            let btn = document.createElement('button')
            title.innerHTML=`${productcard.title}`
            photo.setAttribute('src', `${productcard.image}`)
            btn.innerText= `${productcard.price}`
            DIV.append(title)
            DIV.append(photo)
            DIV.append(btn)
            DIV.classList.add('product')
            products.append(DIV)

            if(productcard.price>200){
                DIV.classList.add('expensive')
            }

            

        })
    })
}