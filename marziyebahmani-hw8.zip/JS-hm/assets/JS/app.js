const firstname = document.getElementById('firstname')
const firstName = document.getElementById('firstName')
function getfirstname(x){
    let name = x.value
    firstName.innerText = name
    if(name== ''){
       firstname.innerText = 'please fill out this section' 
    }else if(name!= ''){
        firstname.innerText = '' 
    if(name.length<5)
        firstname.innerText = 'too short' 
    else if(name.length>10)
         firstname.innerText = 'too long'
    }
}
const phonenumber = document.getElementById('phonenumber')
const phoneNumber = document.getElementById('phoneNumber')
function getphonenumber(e){
    let phone = e.value
    phoneNumber.innerText = phone
     if(phone== ''){
       phonenumber.innerText = 'please fill out this section' 
     }else if(phone!= ''){
        phonenumber.innerText = '' 
    if(phone.length<5)
        phonenumber.innerText = 'too short' 
    else if(phone.length>10)
         phonenumber.innerText = 'too long'
     }
    }
   
