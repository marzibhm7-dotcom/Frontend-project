const table=document.getElementById('table')
let users = JSON.parse(localStorage.getItem("users"));



users.map(user => {
    table.innerHTML += `
        <tr>
            <td>${user.name.firstname}</td>
            <td>${user.name.lastname}</td>
            <td>${user.email}</td>
            <td>${user.username}</td>
            <td>${user.phone}</td>
        </tr>`
    ;
});