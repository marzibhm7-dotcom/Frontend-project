const btn = document.getElementById('btn')


function getUsers(e) {
    fetch("https://fakestoreapi.com/users")
        .then(x => x.json())
        .then(data => {
            let datastr = JSON.stringify(data)
            localStorage.setItem('users',datastr );
      
        });
}