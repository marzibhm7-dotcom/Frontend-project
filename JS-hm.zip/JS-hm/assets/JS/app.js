const firstname = document.getElementById('firstname')
function getfirstname(x){
    let name = x.value
    if(name== ''){
       firstname.innerText = 'please fill out this section' 
    }else if(name!= ''){
        firstname.innerText = '' 
    if(name.length<5)
        firstname.innerText = 'too short' 
    else if(name.length>10)
         firstname.innerText = 'too long'
    }
}
const phonenumber = document.getElementById('phonenumber')
function getphonenumber(e){
    let phone = e.value
     if(phone== ''){
       phonenumber.innerText = 'please fill out this section' 
     }else if(phone!= ''){
        phonenumber.innerText = '' 
    if(phone.length<5)
        phonenumber.innerText = 'too short' 
    else if(phone.length>10)
         phonenumber.innerText = 'too long'
     }
    }