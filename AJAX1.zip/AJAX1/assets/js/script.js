const products = document.getElementById('products')
const xhr= new XMLHttpRequest();
xhr.open('get' , 'assets/api/products.json')
xhr.onload = function(){
if(xhr.readyState == 4 && xhr.status== 200){
    let data = JSON.parse(xhr.responseText)
    console.log(data)
    console.log(typeof(data))
    data.forEach(item => {
        console.log(item)
        products.innerHTML += `
        <tr>
        <td>${item.title}</td>
        <td>${item.price}</td>
        </tr>
        `

        
        
    });
  
}
}
xhr.send()
